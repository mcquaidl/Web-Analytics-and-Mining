# Example: Shiny app that search Wikipedia web pages
# File: server.R 
library(shiny)
library(tm)
library(stringi)
library(proxy)
library(wordcloud)
source("WikiSearch.R")
shinyServer(function(input, output, session) {
  
  terms <- reactive({
      withProgress({
        setProgress(message = "Mining Wikipedia ...")
        result <- SearchWiki(input$select)
      })
    })
  #wordcloud plot
  output$plot <- renderPlot({  
    v <- terms()
    wordcloud(names(v), v, min.freq=5, max.words = 50, colors=brewer.pal(7, "Dark2"))
  })
  
  #data table
  output$mytable <- renderTable({
  v <- terms()
  word.table <- data.frame(names(v[head(ord,n=50)]), v[head(ord,n=50)]) #table 
  #colnames(word.table) <- c("word", "number of times it appears")
  #whenever i try to rename the columns i overwrite all of the data in the rows, which is strange as i am
  #using the above commented out 'colnames' function thus i have left the column names as is
  })
})